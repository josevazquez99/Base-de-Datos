CREATE TABLE ALUMNO(
	dni VARCHAR2(20),
	nombre VARCHAR2(50),
	apellido VARCHAR2(50),
	direccion VARCHAR2(20),
	fecha_nacimiento DATE,
	sexo VARCHAR2(20),
	codigo_curso VARCHAR2(50),
	CONSTRAINT PK_ALUMNO PRIMARY KEY (dni)
);

CREATE TABLE CURSO(
	codigo VARCHAR2(50),
	numero_maximo NUMBER(20),
	fecha_inicio DATE,
	fecha_fin DATE,
	num_horas NUMBER(20),
	dni VARCHAR2(20),
	CONSTRAINT PK_CURSO PRIMARY KEY (codigo)
);

ALTER TABLE ALUMNO ADD CONSTRAINT FK_ALUMNO FOREIGN KEY (codigo_curso) REFERENCES CURSO(codigo);
CREATE TABLE PROFESOR (
	dni VARCHAR2(20),
	nombre VARCHAR2(50),
	direccion VARCHAR2(20),
	titulacion VARCHAR2(20),
	sueldo NUMBER(10,2),
	CONSTRAINT PK_PROFESOR PRIMARY KEY (dni)
);

ALTER TABLE CURSO ADD CONSTRAINT FK_CURSO FOREIGN KEY (dni) REFERENCES PROFESOR (dni);

--No es posible dar de alta un alumno si no se matricula en un curso.

--La informaci�n del n�mero de horas del curso es imprescindible para almacenarlo.

--El campo sueldo de la tabla de profesores no puede estar en ning�n caso vac�o.

--Dos cursos no pueden llamarse igual. Lo mismo pasa con los profesores.

--Podemos identificar las tuplas de la tabla cursos mediante el atributo c�digo y
--profesores y alumnos usando el Dni.

--Cumplir la relaci�n normal entre fecha comienzo y fecha fin (orden cronol�gico).

--Los valores para el atributo sexo son s�lo M y H (en may�scula).

--Se ha de mantener la regla de integridad de referencia.