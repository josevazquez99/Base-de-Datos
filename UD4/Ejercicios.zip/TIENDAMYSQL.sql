CREATE TABLE FABRICANTE(
	codigo INT(10)AUTO_INCREMENT,
	nombre VARCHAR(100),
	CONSTRAINT PK_FABRICANTE PRIMARY KEY (codigo)
);

CREATE TABLE PRODUCTO(
	codigo INT(10)AUTO_INCREMENT,
	nombre VARCHAR(100),
	precio DOUBLE(10,2),
	codigo_fabricante INT(10),
	CONSTRAINT PK_PRODUCTO PRIMARY KEY(codigo),
	CONSTRAINT FK_PRODUCTO FOREIGN KEY (codigo_fabricante) REFERENCES FABRICANTE(codigo)
);

INSERT INTO FABRICANTE (codigo,nombre)
VALUES (1,'Asus');
INSERT INTO FABRICANTE (codigo,nombre)
VALUES (2,'Lenovo');
INSERT INTO FABRICANTE (codigo,nombre)
VALUES (3,'Hewlett-Packard');
INSERT INTO FABRICANTE (codigo,nombre)
VALUES (4,'Samsung');
INSERT INTO FABRICANTE (codigo,nombre)
VALUES (5,'Seagate');
INSERT INTO FABRICANTE (codigo,nombre)
VALUES (6,'Crucial');
INSERT INTO FABRICANTE (codigo,nombre)
VALUES (7,'Gigabyte');
INSERT INTO FABRICANTE (codigo,nombre)
VALUES (8,'Huawei');
INSERT INTO FABRICANTE (codigo,nombre)
VALUES (9,'Xiaomi');


INSERT INTO PRODUCTO (codigo,nombre,precio,codigo_fabricante)
VALUES (1,'Disco duro SATA3 1TB', 86.99, 5);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (2,'Memoria RAM DDR4 8GB', 120, 6);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (3,'Disco SSD 1 TB', 150.99, 4);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (4,'GeForce GTX 1050Ti',185,7);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (5,'Geforce GTX 1080 Xtreme',755,6);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (6,'Monitor 24 LED Full HD',202,1);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (7,'Monitor 27 LED Full HD',245.99,1);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (8,'Port�til Yoga 520',559,2);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (9,'Port�til Ideapd 320',444,2);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (10,'Impresora HP Deskjet 3720',59.99,3);

INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (11,'Impresora HP Laserjet Pro M26nw',180,3);

--Inserta un nuevo fabricante indicando su c�digo y su nombre.
INSERT INTO FABRICANTE (codigo,nombre)
VALUES (10,'Apple');

--Inserta un nuevo fabricante indicando solamente su nombre.
INSERT INTO FABRICANTE (nombre)
VALUES ('HP');
--Inserta un nuevo producto asociado a uno de los nuevos fabricantes. La sentencia de inserci�n debe incluir: c�digo, nombre, precio y c�digo_fabricante.
INSERT INTO PRODUCTO(codigo,nombre,precio,codigo_fabricante)
VALUES (12,'Port�til Apple',1020,10);

--Inserta un nuevo producto asociado a uno de los nuevos fabricantes. La sentencia de inserci�n debe incluir: nombre, precio y c�digo_fabricante.
INSERT INTO PRODUCTO(nombre,precio,codigo_fabricante)
VALUES('Xiaomi 9t',150,9);


--Elimina el fabricante Asus. �Es posible eliminarlo? Si no fuese posible,�qu� cambios deber�a realizar para que fuese posible borrarlo?
-- NO PORQUE TIENE HIJOS
ALTER TABLE PRODUCTO DROP CONSTRAINT FK_PRODUCTO;
ALTER TABLE PRODUCTO ADD CONSTRAINT FK_PRODUCTO FOREIGN KEY (codigo_fabricante) REFERENCES FABRICANTE(codigo) ON DELETE CASCADE;
SELECT * FROM FABRICANTE;
SELECT * FROM PRODUCTO;
DELETE FROM FABRICANTE
WHERE nombre='Asus';
--Elimina el fabricante Xiaomi. �Es posible eliminarlo? Si no fuese posible,�qu� cambios deber�a realizar para que fuese posible borrarlo?
DELETE FROM FABRICANTE
WHERE nombre = 'Xiaomi';

--Actualiza el c�digo del fabricante Lenovo y as�gnale el valor 20. �Es posible actualizarlo? Si no fuese posible, �qu� cambios deber�a realizar para que fuese actualizarlo?
alter table PRODUCTO DROP CONSTRAINT FK_PRODUCTO;
ALTER TABLE PRODUCTO ADD CONSTRAINT FK_PRODUCTO FOREIGN KEY(codigo_fabricante) REFERENCES FABRICANTE(codigo) ON UPDATE CASCADE;
UPDATE FABRICANTE
SET codigo=20
WHERE nombre='Lenovo';


--Actualiza el c�digo del fabricante Huawei y as�gnale el valor 30. �Es posible actualizarlo? Si no fuese posible, �qu� cambios deber�a realizar para que fuese actualizarlo?
UPDATE FABRICANTE
SET codigo=30
WHERE nombre='Huawei';
--Actualiza el precio de todos los productos sum�ndole 5 � al precio actual.
UPDATE PRODUCTO
SET precio=precio+5;
SELECT * FROM PRODUCTO;
--SI NO INTRODUCIMOS EL WHERE LO COGE TODO


--Elimina todas las impresoras que tienen un precio menor de 200 �.
SELECT * FROM PRODUCTO WHERE upper (nombre) LIKE upper('%Impresora%');
DELETE FROM PRODUCTO WHERE upper (nombre) LIKE upper('%Impresora%') AND precio<200;








